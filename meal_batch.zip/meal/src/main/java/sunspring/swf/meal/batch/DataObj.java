package sunspring.swf.meal.batch;

public class DataObj {
	private String EMP_NUM;
	private String EMP_CNAME;
	private String DEPT_CNAME;
	
	public String getEMP_NUM() {
		return EMP_NUM;
	}
	public void setEMP_NUM(String eMP_NUM) {
		EMP_NUM = eMP_NUM;
	}
	public String getEMP_CNAME() {
		return EMP_CNAME;
	}
	public void setEMP_CNAME(String eMP_CNAME) {
		EMP_CNAME = eMP_CNAME;
	}
	public String getDEPT_CNAME() {
		return DEPT_CNAME;
	}
	public void setDEPT_CNAME(String dEPT_CNAME) {
		DEPT_CNAME = dEPT_CNAME;
	}
}
