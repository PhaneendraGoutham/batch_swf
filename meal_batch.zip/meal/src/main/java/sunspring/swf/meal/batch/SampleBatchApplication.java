/*
 * Copyright 2012-2013 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package sunspring.swf.meal.batch;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.BatchConfigurationException;
import org.springframework.batch.core.configuration.annotation.BatchConfigurer;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.batch.item.database.Order;
import org.springframework.batch.item.database.PagingQueryProvider;
import org.springframework.batch.item.database.support.OraclePagingQueryProvider;
import org.springframework.batch.support.DatabaseType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;



@Configuration
@EnableAutoConfiguration
@ComponentScan
@EnableBatchProcessing
public class SampleBatchApplication {
	
	@Autowired
	private JobBuilderFactory jobs;

	@Autowired
	private StepBuilderFactory steps;
	
	@Bean(name="targetDS")
	@ConfigurationProperties(prefix = "spring.ds_target")
	@Primary
	public DataSource targetDataSource() {	
		return DataSourceBuilder.create().build();
	}
	
	@Bean(name="sourceDS")
	@ConfigurationProperties(prefix = "spring.ds_source")
	public DataSource sourceDataSource() {
		return DataSourceBuilder.create().build();
	}
	
	@Bean
	public BatchConfigurer configurer(@Qualifier("targetDS") DataSource ds,PlatformTransactionManager txm,JobRepository rep){
		BatchConfigurer conf=new MyBatchConfig(ds,txm,rep);
		return conf;
	}
	
	@Bean
	public JdbcPagingItemReader<DataObj> reader(@Qualifier("sourceDS") DataSource ds){
		JdbcPagingItemReader<DataObj> reader=new JdbcPagingItemReader<DataObj>();
		reader.setDataSource(ds);
		reader.setPageSize(50);
		reader.setRowMapper(new BeanPropertyRowMapper<DataObj>(DataObj.class));
		reader.setQueryProvider(createQueryProvider());
		

		return reader;
	}
	
	 private PagingQueryProvider createQueryProvider() {//OraclePagingQueryProvider MySqlPagingQueryProvider
		 	OraclePagingQueryProvider queryProvider = new OraclePagingQueryProvider();
	        queryProvider.setSelectClause("SELECT emp_no EMP_NUM, emp_cname EMP_CNAME, dept_cabbr DEPT_CNAME");
	        queryProvider.setFromClause("FROM ITIL.hr_employee_mv@hremp");
	        queryProvider.setWhereClause("WHERE  adj_ename = '在職'");
	        Map<String,Order> sort=new HashMap<String,Order>();
	        sort.put("EMP_NUM", Order.ASCENDING);
	        queryProvider.setSortKeys(sort);
	       
	        return queryProvider;
	    }
	
	@Bean
	public JdbcBatchItemWriter<DataObj> writer(@Qualifier("targetDS") DataSource ds) {
		JdbcBatchItemWriter<DataObj> writer = new JdbcBatchItemWriter<DataObj>();
		writer.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<DataObj>());
		writer.setSql("MERGE INTO SADM.SADM_MEAL_BASE_MAINS t USING (SELECT :EMP_NUM a, :EMP_CNAME b, :DEPT_CNAME c FROM DUAL) s "
				+ "ON (t.EMP_NUM=:EMP_NUM) WHEN MATCHED THEN UPDATE SET t.EMP_CNAME=s.b,t.DEPT_CNAME=s.c "
				+ "WHEN NOT MATCHED THEN INSERT VALUES (s.a,s.b,s.c)");
		writer.setDataSource(ds);
		return writer;
	}
	
	@Bean(name="jobRepository")
	public JobRepository getJobRepository(@Qualifier("targetDS") DataSource ds,PlatformTransactionManager txm) throws Exception {
		JobRepositoryFactoryBean factoryBean = new JobRepositoryFactoryBean();
		factoryBean.setDataSource(ds);
		factoryBean.setDatabaseType(DatabaseType.ORACLE.name());
		factoryBean.setTransactionManager(txm);
		factoryBean.setIsolationLevelForCreate("ISOLATION_READ_COMMITTED");
		factoryBean.setTablePrefix("SADM.BATCH_");
		try {
			factoryBean.afterPropertiesSet();
			return factoryBean.getObject();
		} catch (Exception e) {

			throw new BatchConfigurationException(e);
		}
	}
	

	
	/*@Bean
	public JtaTransactionManager transactionManager() throws Exception{
		UserTransactionManager userTransactionManager = new UserTransactionManager();
		userTransactionManager.setForceShutdown(false);
		UserTransactionImp userTransactionImp = new UserTransactionImp();
		userTransactionImp.setTransactionTimeout(10);
		JtaTransactionManager tx=new JtaTransactionManager(userTransactionImp,userTransactionManager);
		tx.setAllowCustomIsolationLevels(true);
		return tx;
	}*/

	@Bean(name="transactionManager")
	public PlatformTransactionManager transactionManager(@Qualifier("targetDS") DataSource ds){
		DataSourceTransactionManager txa=new DataSourceTransactionManager(ds);
		return txa;
	}
	
	@Bean
	public Job job(Step step1) throws Exception {
		return this.jobs.get("job")
				.start(step1)			
				.build();
	}


	@Bean
	protected Step step1(ItemReader<DataObj> reader,ItemWriter<DataObj> writer) throws Exception {
		return this.steps.get("step1")
				.<DataObj,DataObj>chunk(100)
				.reader(reader)
				.writer(writer)			
				.build();
		
	}

	public static void main(String[] args) throws Exception {
		// System.exit is common for Batch applications since the exit code can be used to
		// drive a workflow
		System.exit(SpringApplication.exit(SpringApplication.run(
				SampleBatchApplication.class, args)));
	}
}
